package com.badlogic.androidgames.framework;

public interface Animation {
    void draw(int x, int y);
    void draw(int x, int y, int width, int height);
}
