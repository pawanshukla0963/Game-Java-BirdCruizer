package com.badlogic.androidgames.framework;

public interface Sound {
    void play(float volume);

    void dispose();
}
