package com.badlogic.androidgames.framework;

public interface Effect {
    /*
    TAG interface
     */
}
