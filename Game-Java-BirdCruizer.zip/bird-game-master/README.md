# Bird game
> A singleplayer offline android game based on LiquidFun

*Bird game* features an endless level in which the goal is to survive for the maximum time as possible.

## Screenshot
![alt text](https://raw.githubusercontent.com/mirkoalicastro/bird-game/master/demo/2.png)
